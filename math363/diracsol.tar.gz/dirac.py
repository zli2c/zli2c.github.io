def findlongerpath(G,P):
    v=eleminsetdifference(G[P[0]],P)
    if not v==-1: return [v]+P
    v=eleminsetdifference(G[P[len(P)-1]],P)
    if not v==-1: return P+[v]
    #We need to know where the vertices appear in P, not their original labels.
    S=[P.index(x) for x in G[P[0]]]
    T=[P.index(x)+1 for x in G[P[len(P)-1]]]
    i=eleminsetintersection(S,T)
    for j in range(len(P)):
        v=eleminsetdifference(G[P[j]],P)
        if v!=-1:
            if j<i:
                return [v]+P[j::-1]+P[i:len(P)]+P[i-1:j:-1]
            else:
                return [v]+P[j:len(P)]+P[i-1::-1]+P[i:j]

def eleminsetintersection(S,T):
    for x in S:
        if x in T:
            return x
    return -1

def eleminsetdifference(S,T):
    for x in S:
        if x not in T:
            return x
    return -1

def findhamcycle(G):
    if len(G)==1: return []
    P=[0]
    while len(P)<len(G):
        P=findlongerpath(G,P)
    S=[P.index(x) for x in G[P[0]]]
    T=[P.index(x)+1 for x in G[P[len(P)-1]]       ]
    i=eleminsetintersection(S,T)
    return P[i:len(P)]+P[i-1::-1]

def checkhamcycle(G,P):
    print len(P)
    if sorted(P)!=range(len(G)):
        print "Not all vertices visited or repeated vertex."
        print "Length:", len(P), "out of",len(G)
        print "Sorted list:",sorted(P)
        return False
    if not all(P[i+1] in G[P[i]] for i in xrange(len(P)-1)):
        i=[P[i+1] in G[P[i]] for i in xrange(len(P)-1)].index(False)
        print "Not all path edges present."
        print "Missing edge number",i,"in path: ",(P[i],P[i+1])
        print "The neighbourhood of",P[i],"is",G[P[i]]
        return False
    if not P[0] in G[P[-1]]:
        print "Final edge",(P[-1],P[0]),"not present."
        print "The neighbourhood of",P[-1],"is",G[P[-1]]
        return False
    return True

#Parse the input. G[v] will contain the neighbours of v (this is N(v) in our usual notation). Vertices are relabelled from 0 to n-1.
G=[map(lambda x: int(x)-1,raw_input().split(",")) for i in range(input())]
P=findhamcycle(G)
#P=map(lambda x:int(x)-1,open("output").read().strip().split(" "))
print " ".join([str(x+1) for x in P])
#print checkhamcycle(G,P)
